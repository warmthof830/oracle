# Terrorism_Viz

## Running on Local Machine
Install npm and node:
```bash
brew install npm node
```

Input the following command:
```bash
npm install
node app.js
```
